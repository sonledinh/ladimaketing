<?php
	$except = ['show'];
    return [
        'recruitments' => [
            'name' => 'recruitments',
            'except' => $except,
            'multi_del' => true,
        ],

        'styles' => [
            'name' => 'styles',
            'except' => $except,
            'multi_del' => true,
        ],


        'projects' => [
            'name' => 'projects',
            'except' => $except,
            'multi_del' => true,
        ],

	];
<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\ProjectDetail;
use App\Models\GalleryLibs;

class ProjectDetailController extends Controller
{
    protected function module()
    {
        return [
            'name'   => 'Dự án chi tiết',
            'module' => 'projects-detail',
        ];
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($idProject)
    {
        $data['module'] = $this->module();
        $data['idProject'] = $idProject;
        return view('backend.projects.projects-detail.create-edit', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $idProject)
    {
        $input = $request->all();
        $input['projects_id'] = $idProject;
        $input['status'] = $request->status == 1 ? 1 : null;
        $projectDt = ProjectDetail::create($input);
        GalleryLibs::createGallery(ProjectDetail::class, $projectDt->id, GalleryLibs::TYPE_PROJECT_DETAIL, $request->gallery);
        flash('Thêm thành công')->success();
        return redirect()->route('projects.edit', $idProject);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($idProject, $id)
    {
        $data['module'] = array_merge($this->module(),[
            'action' => 'update',
        ]);
        $data['data'] = ProjectDetail::findOrFail($id);
        $data['idProject'] = $idProject;
        return view('backend.projects.projects-detail.create-edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$idProject,  $id)
    {
        $input = $request->all();
        $input['status'] = $request->status == 1 ? 1 : null;
        ProjectDetail::find($id)->update($input);
        GalleryLibs::createGallery(ProjectDetail::class, $id, GalleryLibs::TYPE_PROJECT_DETAIL, $request->gallery);
        flash('Cập nhật thành công.')->success();
        return back();

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($idProject, $id)
    {
        flash('Xóa thành công.')->success();
        GalleryLibs::deleteGallery(ProjectDetail::class, $id, GalleryLibs::TYPE_PROJECT_DETAIL);
        ProjectDetail::destroy($id);
        return redirect()->back();
    }
}

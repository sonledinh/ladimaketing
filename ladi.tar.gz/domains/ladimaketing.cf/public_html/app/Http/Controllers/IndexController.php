<?php

namespace App\Http\Controllers;

use App\Mail\SendMailOrders;
use App\Models\Categories;
use App\Models\Customers;
use App\Models\Menu;
use App\Models\Options;
use App\Models\Pages;
use App\Models\Posts;
use App\Trails\MailTrait;
use DB;
use Illuminate\Http\Request;
use Mail;
use OpenGraph;
use SEO;
use SEOMeta;
use App\Models\Contact;
use App\Models\Styles;
use App\Models\Recruitments;
use App\Models\Projects;
use Illuminate\Support\Facades\Validator;

class IndexController extends Controller
{

    use MailTrait;

    public $config_info;

    public function __construct()
    {
        $site_info = Options::where('type', 'general')->first();
        $site_info = json_decode($site_info->content);
        $this->config_info = $site_info;
        OpenGraph::setUrl(\URL::current());
        OpenGraph::addProperty('locale', 'vi');
        OpenGraph::addProperty('type', 'article');
        OpenGraph::addProperty('author', 'GCO-GROUP');
        SEOMeta::addKeyword($site_info->site_keyword);
    }

    public function createSeo($dataSeo = null)
    {
        $site_info = $this->config_info;
        if (!empty($dataSeo->meta_title)) {
            SEO::setTitle($dataSeo->meta_title);
        } else {
            SEO::setTitle($site_info->site_title);
        }
        if (!empty($dataSeo->meta_description)) {
            SEOMeta::setDescription($dataSeo->meta_description);
            OpenGraph::setDescription($dataSeo->meta_description);
        } else {
            SEOMeta::setDescription($site_info->site_description);
            OpenGraph::setDescription($site_info->site_description);
        }
        if (!empty($dataSeo->image)) {
            OpenGraph::addImage($dataSeo->image, ['height' => 400, 'width' => 400]);
        } else {
            OpenGraph::addImage($site_info->logo_share, ['height' => 400, 'width' => 400]);
        }
        if (!empty($dataSeo->meta_keyword)) {
            SEOMeta::addKeyword($dataSeo->meta_keyword);
        }
    }

    public function createSeoPost($data)
    {
        if (!empty($data->meta_title)) {
            SEO::setTitle($data->meta_title);
        } else {
            SEO::setTitle($data->{ 'name_'.app()->getLocale() });
        }
        if (!empty($data->meta_description)) {
            SEOMeta::setDescription($data->meta_description);
            OpenGraph::setDescription($data->meta_description);
        } else {
            SEOMeta::setDescription($this->config_info->site_description);
            OpenGraph::setDescription($this->config_info->site_description);
        }
        if (!empty($data->image)) {
            OpenGraph::addImage($data->image, ['height' => 400, 'width' => 400]);
        } else {
            OpenGraph::addImage($this->config_info->logo_share, ['height' => 400, 'width' => 400]);
        }
        if (!empty($data->meta_keyword)) {
            SEOMeta::addKeyword($data->meta_keyword);
        }
    }

    public function changeLocale($locale)
    {
        session(['lang' => $locale]);
        return redirect()->back();
    }

    public function getHome()
    {
        $this->createSeo();
        $data = Pages::where('type', 'home')->whereLocale(locale())->first();
        $content = $data->content;
        $styles = Styles::whereStatus(1)->orderBy('created_at', 'DESC')->get();
        return view('frontend.pages.home.index', compact('data', 'content', 'styles'));
    }

    public function ventures()
    {
        $contentPage = Pages::where('type', 'ventures')->firstOrFail();
        $this->createSeo($contentPage);
        $styles = Styles::whereStatus(1)->orderBy('created_at', 'DESC')->get();
        return view('frontend.pages.home.ventures', compact('contentPage', 'styles'));
    }

    public function labs()
    {
        $contentPage = Pages::where('type', 'labs')->firstOrFail();
        $this->createSeo($contentPage);
        return view('frontend.pages.labs.index', compact('contentPage'));
    }

    public function research()
    {
        $contentPage = Pages::where('type', 'research')->firstOrFail();
        $this->createSeo($contentPage);
        $styles = Styles::whereStatus(1)->orderBy('created_at', 'DESC')->get();
        return view('frontend.pages.home.research', compact('contentPage', 'styles'));
    }

    public function podcast()
    {
        $contentPage = Pages::where('type', 'podcast')->firstOrFail();
        $this->createSeo($contentPage);
        return view('frontend.pages.podcast.index', compact('contentPage'));
    }

    public function transparency()
    {
        return view('frontend.pages.home.transparency');
    }

    public function careers()
    {
        return view('frontend.pages.home.careers');
    }

    public function contactus()
    {
        $contentPage = Pages::where('type', 'contact')->firstOrFail();
        $this->createSeo($contentPage);
        return view('frontend.pages.contact.contact-us', compact('contentPage'));
    }

    public function pricing()
    {
        return view('frontend.pages.home.pricing');
    }

    public function whoweare()
    {
        return view('frontend.pages.home.who-we-are');
    }

    public function getSinglePosts($slug)
    {
        $data = Recruitments::whereSlug($slug)->whereStatus(1)->firstOrFail();
        $this->createSeoPost($data);
        return view('frontend.pages.posts.index', compact('data'));
    }

    public function getContact()
    {
        $contentPage = Pages::where('type', 'contact')->where('locale', locale())->first();
        $this->createSeo($contentPage);
        return view('frontend.pages.contact.contact-us', compact('contentPage'));
    }

    public function postContact(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ],[
            'email.required' => 'Email required',
            'email.email' => 'Email error',
        ]);


        if ($validator->passes()) {
            $cus          = new Customers;
            $cus->name    = $request->LastName;
            $cus->email   = $request->email;
            $cus->division   = $request->division;
            $cus->message   = $request->message;
            $cus->firstname = $request->FirstName;
            $cus->company = $request->company;
            $cus->save();
            $contact              = new Contact;
            $contact->title       = 'Khách hàng liên hệ';
            $contact->type        = $request->type;
            $contact->customer_id = $cus->id;
            $contact->content     = $request->input('content');
            $contact->status      = 0;
            $contact->save();
            return response()->json(['success'=>'Thank you! Your submission has been received!']);
        }


        return response()->json(['error'=>$validator->errors()->all()]);
        
        // $dataEmail = [
        //     'name'    => $request->name,
        //     'phone'   => $request->phone,
        //     'email'   => $request->email,
        //     'content' => $request->input('content'),
        //     'title'   => $request->type == 'contact' ? 'Khách hàng liên hệ.' : '',
        //     'type'    => $request->type,
        // ];
      // return response()->json(array(), 200);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\ProjectDetail;

class Projects extends Model
{
    protected $table = 'projects';

    protected $fillable = [
        'name_vi',
        'name_en',
        'slug',
        'status',
        'meta_title',
        'meta_description',
        'meta_keyword',
        'image'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function projectDetail()
    {
        return $this->hasMany(ProjectDetail::class, 'projects_id', 'id')->orderBy('project_details.created_at', 'DESC');
    }
}

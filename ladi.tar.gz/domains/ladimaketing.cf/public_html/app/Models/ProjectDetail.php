<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectDetail extends Model
{
    protected $table = 'project_details';

    protected $fillable = [
        'projects_id',
        'name_vi',
        'name_en',
        'sub_name_vi',
        'sub_name_en',
        'status',
        'banner'
    ];

    public function getGalleryProjectDetail()
    {
        return GalleryLibs::getGallery(ProjectDetail::class, $this->id, GalleryLibs::TYPE_PROJECT_DETAIL);
    }
}
